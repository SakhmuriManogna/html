package com.myassesment.model;

public class Students {
	
	private int studId;
	private String studName;
	private int sem;
	public Students(int studId, String studName, int sem) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.sem = sem;
	}
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public int getSem() {
		return sem;
	}
	public void setSem(int sem) {
		this.sem = sem;
	}
	@Override
	public String toString() {
		return "Students [studId=" + studId + ", studName=" + studName + ", sem=" + sem + "]";
	}
	
	

}
