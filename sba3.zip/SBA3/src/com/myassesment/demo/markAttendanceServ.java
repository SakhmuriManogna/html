package com.myassesment.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myassesment.dao.StudentDao;
import com.myassesment.dbutil.DbConnection;
import com.myassesment.model.Students;





@WebServlet("/markAttendanceServ")
public class markAttendanceServ extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		try {
		
		int sem=Integer.parseInt(request.getParameter("sem"));
		
		StudentDao dao=new StudentDao();
	
		ArrayList<Students> studentsem= dao.displaySem(sem);
		
		HttpSession session=request.getSession();
		session.setAttribute("studs", studentsem);
		session.setAttribute("sem", sem);
		
		
		RequestDispatcher rd= request.getRequestDispatcher("markAttendanceForm.jsp");
		rd.forward(request, response);
		
		}
		catch (Exception e) {
			out.print("<html>");
			out.print("<script type=\"text/javascript\">");
			out.print("alert('please select sem');");
			out.print("</script>");
			
			out.print("</html>");
			
			e.printStackTrace();
			
		}
		
		
		
		
	
	
	
	
	}
	
}
